
<template>
  <div>
    <div class="wrapper fadeInDown">
      <div id="formContent" class="d-flex justify-content-center align-items-center flex-column">
        <!-- Icon -->
        <div class="fadeIn first">
          <img src="@/assets/avatar.svg" id="icon" alt="User Icon" style="width: 150px" />
        </div>

        <p>{{ errorMessage }}</p>

        <div class="form-group d-flex">
          <input v-model="documento" placeholder="Ingrese su documento" class="form-control" />
          <button @click="redirigir" class="btn btn-primary">OK</button>
        </div>

        <table v-show="Object.keys(paciente).length > 0 && documento" class="styled-table">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Documento</th>
                          <th>Nombre</th>
                          <th>Apellido</th>
                          <th>Edad</th>
                          <th>Género</th>
                          <th>EPS</th>
                          <th>TP</th>
                          <th>PTT</th>
                          <th>AT_lll</th>
                          <th>TT</th>
                          <th>Fibrinogeno</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr v-for="result in paciente" :key="result.doc">
                          <td>{{ result.id }}</td>
                          <td>{{ result.doc }}</td>
                          <td>{{ result.name }}</td>
                          <td>{{ result.lastname }}</td>
                          <td>{{ result.age }}</td>
                          <td>{{ result.gender }}</td>
                          <td>{{ result.EPS }}</td>
                          <td>{{ result.TP }}</td>
                          <td>{{ result.PTT }}</td>
                          <td>{{ result.AT_lll }}</td>
                          <td>{{ result.TT }}</td>
                          <td>{{ result.fibrinogeno }}</td>
                        </tr>
                      </tbody>
                    </table>
    
                    <!-- Remind Passowrd -->
                    <div class="alert alert-danger" role="alert" v-if="error">
                       {{error_msg}}
                    </div>
    
                  </div>
                </div>
          </div>
</template>
<script>
export default {
  data() {
    return {
      paciente: {},
      documento: "",
      errorMessage: "",
    };
  },
  methods: {
    async redirigir() {
      if (this.documento) {
        try {
          const url = `http://localhost/api/?documento=${this.documento}`;
          const response = await fetch(url);

          if (response.ok) {
            this.paciente = await response.json();
            if (Object.keys(this.paciente).length === 0) {
              this.errorMessage = "El documento ingresado no existe";
            } else {
              this.errorMessage = "";
            }
          } else {
            console.error("No se pudo realizar la solicitud a la URL.");
          }
        } catch (error) {
          console.error(error);
        }
      } else {
        this.errorMessage = "Por favor, ingrese su documento antes de presionar OK.";
      }
    },
  },
};
</script>

<style>
.styled-table {
  width: 100%;
  border-collapse: collapse;
  border-spacing: 0;
  text-align: center;
  margin: 20px auto;
  border: 2px solid #ccc;
  border-radius: 8px;
}

.styled-table th, .styled-table td {
  border: 1px solid #ccc;
  padding: 8px;
}

.styled-table th {
  background-color: #f2f2f2;
}
.custom-button {
  background-color: transparent; 
  border: 1px solid #060707; 
  color: #060707; 
  transition: background-color 0.3s; 
  cursor: pointer; 
}

.custom-button:hover {
  border: 1px solid #40AEB3;; 
  color: #40AEB3; 
}

</style>