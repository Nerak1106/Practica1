import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import 'bootstrap/dist/css/bootstrap.css'; // Importa los estilos CSS de Bootstrap
import 'bootstrap/dist/js/bootstrap.js';   // Importa los scripts de JavaScript de Bootstrap
import 'bootstrap-icons/font/bootstrap-icons.css';

createApp(App).use(router).mount('#app')
